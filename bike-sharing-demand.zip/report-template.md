# Report: Predict Bike Sharing Demand with AutoGluon Solution
#### NAME HERE

## Initial Training
### What did you realize when you tried to submit your predictions? What changes were needed to the output of the predictor to submit your results?
 The first thing I found out was that I forgot the pharse data frame to make it clearer and I forgot to put the features or do drop casual and registered columns and because of that an error occurred when I am making a test

### What was the top ranked model that performed?
WeightedEnsemble_L3  

## Exploratory data analysis and feature creation
### What did the exploratory analysis find and how did you add additional features?
I was able to see the number of hours in a clearer way on holidays and normal days

### How much better did your model preform after adding additional features and why do you think that is?
I was able to see the number of hours in a clearer way on holidays and normal days and avioding error appened in test data

## Hyper parameter tuning
### How much better did your model preform after trying different hyper parameters?
some configurations is usefull but others not as much good for  the model performance

### If you were given more time with this dataset, where do you think you would spend more time?
to analysis my data
### Create a table with the models you ran, the hyperparameters modified, and the kaggle score.
(img/1.png)
model	hpo1	hpo2	hpo3	score
0	initial	default	default	default	1.81080
1	add_features	default	default	default	0.46051
2	hpo	GBM:'num_boost_round': 100,'num_leaves'(lower=26, upper=66, default=36)	NN_TORCH (num_epochs': 10), activation('relu', 'softrelu', 'tanh')	searcher: 'auto', num_trials: 5,scheduler: local	4.76188
### Create a line plot showing the top model score for the three (or more) training runs during the project.

TODO: Replace the image below with your own.

![model_train_score.png](img/model_train_score.png)

### Create a line plot showing the top kaggle score for the three (or more) prediction submissions during the project.

TODO: Replace the image below with your own.

![model_test_score.png](img/model_test_score.png)


## Summary
TODO: Add your explanation
